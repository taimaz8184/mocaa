const UserModel = require("../../models/user");
let searchUserResolvers = {
    Query: {
        searchUser: async (parent, args) => {
            let query = args.query;
            let query_search = {};
            if (query) query_search = new RegExp(query, "gi");
            let users = await UserModel.find({
                $or: [{ firstName: query_search }, { lastName: query_search }]
            });
            return users;
        }
    }
};
module.exports = searchUserResolvers;