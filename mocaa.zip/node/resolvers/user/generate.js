const UserModel = require("../../models/user");
var faker = require('faker');

let generateResolvers = {
  Mutation: {
    generate: async (parent, args) => {
      for (let index = 0; index < 10000; index++) {
        let firstName = faker.name.firstName()
        let lastName = faker.name.lastName()
        let jobTitle = faker.name.jobTitle()
        let jobCategory = faker.name.jobType()
        let email = faker.internet.email()
        let age = faker.random.number({ min: 20, max: 60 })
        let location = faker.address.country()
        let joined = faker.date.past()
        let avatar = `${faker.image.people()}?random=${Date.now()}`
        await UserModel.create({
          firstName, lastName, email, jobTitle, jobCategory, age, location, joined, avatar
        })
      }
      return true
    },
  },
};
module.exports = generateResolvers;
