const express = require("express");
const app = express();
const cors = require('cors')
const {
  ApolloServer,
  gql
} = require("apollo-server-express");
require("dotenv").config();
const merge = require("lodash/merge");
const path = require("path");

app.use(express.static(path.join(__dirname, "public")));

/** Import Schemas */
let Users = require("./schemas/users");
const types = [];
const queries = [];
const mutations = [];
const schemas = [Users];
schemas.forEach((s) => {
  types.push(s.types);
  queries.push(s.queries);
  mutations.push(s.mutations);
});

/** Import Resolvers */
let generateResolvers = require("./resolvers/user/generate");
let searchUserResolvers = require("./resolvers/user/searchUser");

/** DB Connection */
const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost/mocaa", {
  useCreateIndex: true,
  useUnifiedTopology: true,
  useNewUrlParser: true,
  useFindAndModify: false,
});
mongoose.Promise = global.Promise;

/** Model */
const UserModel = require("./models/user");

let typeDefs = gql`
  type Query {
    user(id: String!): User
    ${queries.join("\n")}
  }

  type Mutation {
    ${mutations.join("\n")}
  }

  ${types.join("\n")}

  schema {
    query: Query
    mutation: Mutation
  }
`;

let relations = {
  Query: {
    user: async (parent, args) => await UserModel.findById(args.id),
  }
};

const resolvers = merge(
  relations,
  generateResolvers,
  searchUserResolvers
);

const server = new ApolloServer({
  typeDefs,
  resolvers,
  playground: process.env.NODE_ENV == "production" ? false : true,
});

server.applyMiddleware({
  app,
  path: "/graphql",
});

app.listen({
  port: 4000,
},
  () => console.log("server is running")
);