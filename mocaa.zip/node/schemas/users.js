const types = `
    type User {
        email: String
        firstName: String
        lastName: String
        age: Int
        jobTitle: String
        jobCategory: String
        location: String
        joined: String
        avatar: String
    }
`;
const queries = `
    searchUser(query:String!): [User]
`;
const mutations = `
    generate : Boolean    
`;
module.exports = { types, queries, mutations };