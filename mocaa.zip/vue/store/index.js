export const strict = false;

export const state = () => ({
  users: [],
  loading: false,
  short_text: false,
  no_filter_user: false,
  filter_location: '',
  filter_job: '',
  filter_age: [20, 60]
});

export const mutations = {
  // Search user
  async searchUser(state, query) {
    state.loading = true
    state.short_text = false
    /** Query */
    let codeData = {
      query: `
        query search($query:String!){
          searchUser(query:$query) {
            firstName
            lastName
            email
            age
            jobTitle
            jobCategory
            location
            joined
            avatar
          }
        }
      `,
      variables: {
        query
      }
    };
    /** Send Data */
    if (query.length >= 3) {
      try {
        let res = await fetch(process.env.graphUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", },
          body: JSON.stringify(codeData)
        });
        let response = await res.json();
        state.users = response.data.searchUser;
        state.loading = false
        state.short_text = false
      } catch (error) { }
    } else {
      state.short_text = true
    }
  },
};
