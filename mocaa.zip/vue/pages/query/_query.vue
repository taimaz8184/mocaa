<template>
  <section>
    <app-header />
    <!-- Data -->
    <v-container fluid v-if="!$store.state.loading">
      <v-row
        class="h-100"
        v-if="users.length > 0 || $store.state.no_filter_user"
      >
        <filters />
        <results />
      </v-row>
      <v-row
        v-if="users.length == 0 && !$store.state.no_filter_user"
        class="mt-5"
      >
        <v-col cols="12" md="12" class="text-center">
          <p class="display-1">No employees were found.</p>
          <p class="body-1">Please try another name.</p>
        </v-col>
      </v-row>
    </v-container>
    <!-- Loader -->
    <v-btn
      v-if="
        $store.state.loading &&
        !$store.state.short_text &&
        !$store.state.no_filter_user
      "
      :loading="true"
      plain
      x-large
      class="loader"
    >
    </v-btn>
    <!-- Alert for less than 3 characters -->
    <v-container v-if="$store.state.short_text && !$store.state.no_filter_user">
      <v-row class="mt-5">
        <v-col cols="12" md="6" class="mx-auto">
          <v-alert type="info">
            Please type at least 3 characters to search for employees
          </v-alert>
        </v-col>
      </v-row>
    </v-container>
  </section>
</template>
<script>
import AppHeader from '~/components/AppHeader'
import Filters from '~/components/Filters'
import Results from '~/components/Results'
export default {
  components: {
    AppHeader,
    Filters,
    Results,
  },
  created() {
    this.$store.commit('searchUser', this.$route.params.query)
  },
  computed: {
    users() {
      return this.$store.state.users
    },
  },
}
</script>
<style scoped>
.loader {
  width: 100%;
}
</style>
