<template>
  <v-col cols="12" md="7" class="mx-auto text-center mt-10">
    <h3 class="mb-5">Use generate button to create 10K users</h3>
    <v-btn color="green" class="white--text mr-2" @click="generateUser"
      >Generate</v-btn
    >
    <nuxt-link to="/">
      <v-btn color="white" class="black--text"
        >Back to home page</v-btn
      ></nuxt-link
    >
    <!-- Loader -->
    <v-col cols="12" md="7" class="mx-auto text-center mt-10">
      <v-btn v-if="loading" :loading="loading" plain x-large class="loader">
      </v-btn>
    </v-col>
    <!-- Notification -->
    <v-alert
      v-if="msg && !loading"
      class="mt-5 font-weight-bold"
      :type="msg_type"
      >{{ msg }}</v-alert
    >
  </v-col>
</template>
<script>
export default {
  data() {
    return {
      loading: false,
      msg: '',
      msg_type: '',
    }
  },
  methods: {
    async generateUser() {
      this.loading = true
      this.msg = ''
      this.msg_type = ''
      const codeData = {
        query: `
          mutation {
            generate
          }
       `,
      }

      try {
        const res = await fetch(process.env.graphUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(codeData),
        })
        const response = await res.json()
        this.loading = false
        if (response.errors) {
          this.msg = response.errors[0].message
          this.msg_type = 'error'
        } else {
          this.msg = '10K Users has been created.'
          this.msg_type = 'success'
        }
      } catch (error) {}
    },
  },
}
</script>
