<template>
  <section class="mocaa-main-page d-flex align-center">
    <section class="bg-layer"></section>
    <v-row>
      <v-col cols="10" md="4" class="mx-auto">
        <v-form
          @submit.prevent="searchData"
          class="mx-auto d-flex align-center"
        >
          <v-text-field
            v-model="query"
            label="Search employee by name"
            dark
            flat
            solo-inverted
            hide-details
            clearable
            clear-icon="mdi-close-circle-outline"
          ></v-text-field>
          <v-btn
            color="info"
            large
            class="ml-3"
            type="submit"
            :disabled="query.length < 3"
          >
            <v-icon>mdi-magnify</v-icon>
          </v-btn>
        </v-form>
        <p class="white--text mt-2">Type at least 3 characters</p>
      </v-col>
    </v-row>
  </section>
</template>
<script>
export default {
  data() {
    return {
      query: '',
    }
  },
  methods: {
    searchData() {
      this.$store.commit('searchUser', this.query)
      this.$router.push({ path: `query/${this.query}` })
    },
  },
}
</script>
