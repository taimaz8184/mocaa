<template>
  <v-col class="px-4">
    <v-range-slider
      v-model="$store.state.filter_age"
      :max="max"
      :min="min"
      hide-details
      label="Age: "
      thumb-label="always"
      class="align-center age-filter"
    >
    </v-range-slider>
  </v-col>
</template>
<script>
export default {
  data() {
    return {
      min: 20,
      max: 60,
    }
  },
}
</script>
<style scoped>
</style>
