<template>
  <v-col class="px-4">
    <v-autocomplete
      v-model="$store.state.filter_location"
      :items="items"
      dense
      filled
      label="Location"
    ></v-autocomplete>
  </v-col>
</template>
<script>
export default {
  data() {
    return {
      items: [],
    }
  },
  mounted() {
    let users = this.$store.state.users
    for (let index = 0; index < users.length; index++) {
      this.items.push(users[index].location)
    }
  },
}
</script>
