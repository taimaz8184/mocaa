<template>
  <v-col class="px-4">
    <v-autocomplete
      v-model="$store.state.filter_job"
      :items="items"
      dense
      filled
      label="Job Category"
    ></v-autocomplete>
  </v-col>
</template>
<script>
export default {
  data() {
    return {
      items: [],
    }
  },
  mounted() {
    let users = this.$store.state.users
    for (let index = 0; index < users.length; index++) {
      this.items.push(users[index].jobCategory)
    }
  },
}
</script>
