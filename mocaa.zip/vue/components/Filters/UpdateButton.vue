<template>
  <v-col class="px-4">
    <v-btn color="success" @click="applyFilter">Apply</v-btn>
    <v-btn color="light" @click="refresh">Reset</v-btn>
  </v-col>
</template>
<script>
export default {
  methods: {
    async applyFilter() {
      let users = this.$store.state.users
      this.$store.state.no_filter_user = false

      let location = this.$store.state.filter_location
      let job = this.$store.state.filter_job
      let age = this.$store.state.filter_age

      let filter = users.filter((user) => {
        if (location && job) {
          return (
            user.location === location &&
            user.jobCategory === job &&
            user.age >= age[0] &&
            user.age <= age[1]
          )
        } else if (location || job) {
          return (
            (user.location === location || user.jobCategory === job) &&
            user.age >= age[0] &&
            user.age <= age[1]
          )
        } else {
          return user.age >= age[0] && user.age <= age[1]
        }
      })

      this.$store.state.users = filter
      if (filter.length == 0) {
        this.$store.state.no_filter_user = true
      }
    },
    refresh() {
      window.location.reload()
    },
  },
}
</script>
