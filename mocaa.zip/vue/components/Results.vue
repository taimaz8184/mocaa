<template>
  <v-col cols="12" md="8" class="results px-10 pt-10">
    <section
      v-if="!$store.state.no_filter_user"
      class="d-flex flex-row align-items-center justify-space-between"
    >
      <v-toolbar-title class="mb-10">
        <span class="blue--text font-weight-bold">{{
          $store.state.users.length
        }}</span>
        employees found</v-toolbar-title
      >
      <sort />
    </section>
    <employee v-if="!$store.state.no_filter_user" />
    <p v-if="$store.state.no_filter_user" class="display-1 text-center">
      No employees were found.
    </p>
    <p v-if="$store.state.no_filter_user" class="body-1 text-center">
      Please try another filter.
    </p>
  </v-col>
</template>
<script>
import Employee from './Employee'
import Sort from './Sort'
export default {
  components: {
    Employee,
    Sort,
  },
}
</script>
