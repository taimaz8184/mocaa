<template>
  <v-app-bar color="purple darken-1" fixed app>
    <v-col col="12" md="3">
      <v-form @submit.prevent="searchData" class="mx-auto d-flex align-center">
        <v-text-field
          v-model="query"
          label="Search employee by name and press enter"
          dark
          flat
          hide-details
          clearable
          clear-icon="mdi-close-circle-outline"
        ></v-text-field>
      </v-form>
    </v-col>
    <v-spacer />
    <nuxt-link to="/">
      <v-toolbar-title class="white--text" v-text="'Mocaa'" />
    </nuxt-link>
  </v-app-bar>
</template>
<script>
export default {
  data() {
    return {
      query: this.$route.params.query,
    }
  },
  methods: {
    searchData() {
      if (this.query !== null) {
        this.$store.commit('searchUser', this.query)
        this.$router.push({ path: `${this.query}` })
      }
    },
  },
}
</script>
