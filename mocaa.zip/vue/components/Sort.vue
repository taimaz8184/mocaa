<template>
  <v-menu offset-y>
    <template v-slot:activator="{ on, attrs }">
      <v-btn color="primary" dark v-bind="attrs" v-on="on">
        Sort by
        <span v-if="active">: {{ active }}</span>
        <v-icon small class="ml-1">mdi-arrow-down-drop-circle-outline</v-icon>
      </v-btn>
    </template>
    <v-list>
      <v-list-item
        v-for="(item, index) in items"
        :key="index"
        @click="changeSort(item.title)"
      >
        <v-list-item-title class="text-capitalize">{{
          item.title
        }}</v-list-item-title>
      </v-list-item>
    </v-list>
  </v-menu>
</template>
<script>
import moment from 'moment'
export default {
  data() {
    return {
      items: [{ title: 'age' }, { title: 'date' }],
      active: '',
    }
  },
  methods: {
    async changeSort(value) {
      this.active = value

      let users = this.$store.state.users

      if (value == 'age') {
        this.$store.state.users = users.sort((a, b) => b.age - a.age)
      } else {
        this.$store.state.users = users.sort((a, b) => {
          a = new Date(a.joined)
          b = new Date(b.joined)
          var results = a > b ? -1 : a < b ? 1 : 0
          return results * 1
        })
      }
    },
  },
}
</script>
