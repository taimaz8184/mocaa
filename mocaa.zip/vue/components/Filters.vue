<template>
  <v-col cols="12" md="3" class="filters px-10 pt-10">
    <v-banner sticky app>
      <v-toolbar-title> Filters</v-toolbar-title>
      <v-divider class="mt-2 mb-15"></v-divider>
      <age class="mb-5" />
      <job-area />
      <location />
      <update-button />
    </v-banner>
  </v-col>
</template>
<script>
import Age from './Filters/Age'
import JobArea from './Filters/JobArea.vue'
import Location from './Filters/Location.vue'
import UpdateButton from './Filters/UpdateButton.vue'
export default {
  components: {
    Age,
    JobArea,
    Location,
    UpdateButton,
  },
}
</script>
<style scoped>
.filters {
  background: #eee;
}
</style>
