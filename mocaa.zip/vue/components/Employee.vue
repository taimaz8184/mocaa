<template>
  <v-row>
    <v-col v-for="(user, i) in users" :key="i" cols="12" md="4">
      <v-card class="mx-auto mb-5" color="#26c6da" dark>
        <v-card-title>
          <v-toolbar-title class="title d-block font-weight-light">{{
            user.jobTitle
          }}</v-toolbar-title>
          <v-toolbar-title
            class="caption email text-lowercase d-block font-weight-light"
            >{{ user.email }}</v-toolbar-title
          >
          <v-toolbar-title class="caption d-block font-weight-light"
            >From: {{ user.location }}</v-toolbar-title
          >
        </v-card-title>

        <v-card-actions>
          <v-list-item class="grow">
            <v-list-item-avatar color="grey darken-3">
              <v-img
                class="elevation-6"
                :alt="user.firstName"
                :src="user.avatar"
              ></v-img>
            </v-list-item-avatar>

            <v-list-item-content>
              <v-list-item-title
                >{{ user.firstName }} {{ user.lastName }}</v-list-item-title
              >
              <span class="caption">{{ user.age }} years old</span>
            </v-list-item-content>
          </v-list-item>
        </v-card-actions>

        <v-divider class="mx-4"></v-divider>

        <v-card-title class="caption py-2"
          >Joined in {{ convertDate(user.joined) }}</v-card-title
        >
      </v-card>
    </v-col>
  </v-row>
</template>
<script>
import moment from 'moment'
export default {
  methods: {
    convertDate(val) {
      let date = moment(val).format('MMM YYYY')
      return date
    },
  },
  computed: {
    users() {
      return this.$store.state.users
    },
  },
}
</script>
<style scoped>
.d-block {
  width: 100%;
}
</style>
